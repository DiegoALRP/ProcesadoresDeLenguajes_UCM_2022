package alex0;

public enum ClaseLexica {
    Sep_seccion, PuntoComa, Entero, Real, Bool, True, False, Variable, Asignacion, NumeroEntero,
    NumeroReal, And, Or, Not, Mas, Menos, Por, Div, Menor, Mayor, Menor_igual, Mayor_igual, Igual_igual,
    Distinto, Par_aper, Par_cier, EOF
}
